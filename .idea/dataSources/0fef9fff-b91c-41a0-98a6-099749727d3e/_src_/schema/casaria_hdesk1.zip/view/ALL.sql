CREATE VIEW `ALL` AS
  SELECT
    `casaria_hdesk1`.`TABLE 66`.`CUSTOMER_CLASS` AS `CUSTOMER_CLASS`,
    `casaria_hdesk1`.`TABLE 66`.`CLASS_CODE`     AS `CLASS_CODE`,
    `casaria_hdesk1`.`TABLE 66`.`DATE`           AS `DATE`,
    `casaria_hdesk1`.`TABLE 66`.`EMPLOYEE`       AS `EMPLOYEE`,
    `casaria_hdesk1`.`TABLE 66`.`DESCRIPTION`    AS `DESCRIPTION`,
    `casaria_hdesk1`.`TABLE 66`.`TIME`           AS `TIME`,
    `casaria_hdesk1`.`TABLE 66`.`GROSS_RATE`     AS `GROSS_RATE`
  FROM `casaria_hdesk1`.`TABLE 66`
  WHERE 1;
